<?php

declare(strict_types=1);

return [
    'failed'   => 'Identitas tersebut tidak cocok dengan data kami.',
    'password' => 'Kata sandi salah.',
    'throttle' => 'Terlalu banyak upaya masuk. Silahkan coba lagi dalam :seconds detik.',
];
